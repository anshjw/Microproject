// Demo product data
const products = [
  { name: "Compound Microscope", price: "₹65,000" },
  { name: "Analytical Balance", price: "₹45,000" },
  { name: "pH Meter", price: "₹12,000" },
  { name: "Glass Beaker Set", price: "₹2,400" }
];

const grid = document.getElementById("productGrid");
if (grid) {
  products.forEach(p => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <h3>${p.name}</h3>
      <p>Price: ${p.price}</p>
      <button>Add to Cart</button>
    `;
    grid.appendChild(card);
  });
}
